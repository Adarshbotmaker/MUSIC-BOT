<p align="center">
    <a href="https://app.codacy.com/gh/TEAM-PATRICIA/PatriciaMusic2.0/dashboard?branch=Legacy"> <img src="https://img.shields.io/codacy/grade/4d58f2a402b54aed8a7d95f7add45a81?color=cyan&logo=codacy&logoColor=white&style=for-the-badge" alt="Codacy" /></a>
    <a href="https://github.com/anglefree/quicktriviav4.git"> <img src="https://img.shields.io/github/repo-size/TeamInnexia/innexiaBot?color=cyan&logo=github&logoColor=white&style=for-the-badge" /></a>
</p>


# quicktriviav4👮
💡 This is Innexia An Advanced Telegram CHAT Bot For Best AI Experience made by AXEL!! 🤖 

![logo] (https://https://telegra.ph/file/63667b69b432653bd1683.jpg)
#  💡Dᴇᴠᴇʟᴏᴩᴇᴍᴇɴᴛ•Sᴜᴩᴩᴏʀᴛ👥[Here !](https://t.me/AXEL_SUPPORT)

## Me On Telegram As [💥 AXEL 💥](https://t.me/SURAJ_O_P)

## Cᴏᴍᴍᴀɴᴅs
```
->Music•Player<- by AXEL
=>> *Song Playing* 🎧 
❍ /play  - play song you requested
❍ /dplay  - play song you requested via deezer
❍ /splay  - play song you requested via jio saavn
❍ /playlist - Show now playing list
❍ /current - Show now playing
❍ /song  - download songs you want quickly
❍ /search  - search videos on youtube with details
❍ /deezer  - download songs you want quickly via deezer
❍ /saavn  - download songs you want quickly via saavn
❍ /video  - download videos you want quickly
=>> *Admins only*
❍ /player - open music player settings panel
❍ /pause - pause song play
❍ /resume - resume song play
❍ /skip - play next song
❍ /end - stop music play
❍ /userbotjoin - invite assistant to your chat
❍ /admincache - Refresh admin list

```


## 💡 How To Host ❓️


## DEPLOY ON HEROKU 🚀

<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/SURAJOP7/quicktriviav4"><img align="center" alt="Heroku" width="52px" src="https://www.nicepng.com/png/full/223-2233246_heroku-logo-salesforce-heroku.png"></p>
 

