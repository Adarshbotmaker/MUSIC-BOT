from W2HMUSIC1.function.admins import admins
from W2HMUSIC1.function.admins import get
from W2HMUSIC1.function.admins import set

__all__ = ["set", "get", "admins"]
